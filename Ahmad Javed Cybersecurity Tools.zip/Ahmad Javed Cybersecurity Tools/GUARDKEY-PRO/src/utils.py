# Utility functions (placeholder)
